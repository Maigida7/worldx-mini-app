WORLDX MINI APP
================
This is a front-end prototype for the WorldX Telegram Mini App.

Included:
- WorldX mining/tap screen
- Energy system
- Daily reward
- Referral demo
- Tasks
- Leaderboard
- Mobile-first Telegram-style dark UI

IMPORTANT:
This prototype stores state only in the current page. It is NOT yet connected to Telegram users,
a database, real referrals, real tasks, or a token/blockchain.

To use as Telegram Web App, deploy index.html to a public HTTPS host, then use that HTTPS URL
in Telegram's Web App configuration.
